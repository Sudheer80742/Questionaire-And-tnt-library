sap.ui.define([
	"rbx.107.stuexe/test/unit/controller/View1.controller"
], function () {
	"use strict";
});
