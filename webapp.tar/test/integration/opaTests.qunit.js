/* global QUnit */

sap.ui.require(["rbx/107/stuexe/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
