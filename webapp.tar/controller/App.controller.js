sap.ui.define([
  "sap/ui/core/mvc/Controller"
], (Controller) => {
  "use strict";

  return Controller.extend("rbx.107.stuexe.controller.App", {
      onInit() {
      }
  });
});